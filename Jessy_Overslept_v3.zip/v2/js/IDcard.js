class IDcard extends GameObject {
    constructor(engine){
        super(engine);
        this.position = {x: 0,y:0};
        this.image = document.createElement("img");
        this.image.src = "./img/bio_san_ins.png";
        this.image.onload = () => {
            console.log("bio_san_ins.png ok");
        }
        this.energy = 0;
        this.blood = 0;
    }

    draw() {
        // this.engine
        // this.ctx
        this.engine.ctx.drawImage(
            this.image,
            this.position.x,this.position.y
        )
    }

    update(time) {
        // this.engine
        // this.ctx
    }
}