class InfoBarObject extends GameObject {
    constructor(engine) {
        super(engine);
        this.position = {x:800,y:20};
        this.maxnum = 105;
        this.nownum = 30;
        this.scale = {x:this.nownum,y:8};
        this.color = "black";//"#E71E0A";
        this.name = "InfoBar";

        // this.collider = new RectCollider(this, { width: 150, height: 50 });
    }

    update(time) {
        // Update this.nownum
        // console.log(this.nownum)
        this.nownum = (this.nownum>this.maxnum)?this.maxnum:this.nownum;
        this.nownum = (this.nownum<0)?0:this.nownum;
        this.scale = {x:this.nownum,y:10};
    }

    draw() {
        // this.collider.draw();
        // console.log("hi");
        this.engine.ctx.fillStyle = this.color;
        this.engine.ctx.fillRect(this.position.x,this.position.y,this.scale.x,this.scale.y);
    }
}