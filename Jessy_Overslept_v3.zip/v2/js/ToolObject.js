class ToolObject extends GameObject {
    constructor(engine) {
        super(engine);
        this.engine = engine;
        this.position = {x:0,y:0};
        this.scale = {x:0,y:0};
        this.imgpath1 = "";
        this.imgpath2 = "";
        // Create image
        // this.image = document.createElement('img');
        // this.image.src = this.imgPath;
        // this.image.onload = () => {
        //     this.ready = true;
        // };
        // console.log(this.ready);
        this.inUse = false;
        this.name = "Tool";
    }

    update(time) {
        // Update this.nownum
        // console.log(this.nownum)
        
    }

    draw() {
        // this.collider.draw();
        
    }
}