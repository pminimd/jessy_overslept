class EnergyBar extends InfoBarObject{
    constructor(engine) {
        super(engine);
        this.position = {x:79,y:132};
        this.maxnum = 105;
        this.scale = {x:this.maxnum,y:8};
        this.nownum = 50;
        this.color = "black";//"#3AC2FC";
        this.name = "EnergyBar";
    }
    // update(time){
    //     // this.nownum = 20;
    // }
}