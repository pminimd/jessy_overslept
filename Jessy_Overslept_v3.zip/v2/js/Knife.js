class Knife extends ToolObject{
    constructor(engine) {
        super(engine);

        this.engine = engine;
        this.position = {x:900,y:400};
        this.scale = {x:100,y:100};
        this.imgpath1 = "./img/tools/knife_nothing.png";
        this.imgpath2 = "./img/tools/knife.png";
        
        this.image1 = document.createElement("img");
        this.image2 = document.createElement("img");
        this.image1.src = this.imgpath1;
        this.image2.src = this.imgpath2;
        this.image1.onload = () => {
            console.log("knife_nothing.png ok");
        };
        this.image2.onload = () => {
            console.log("knife.png ok");
        };
        this.inUse = false;

        this.name = "Knife";
        this.hand = "hand_knife";
    }

    update(time) {
        //inUse是否需要改变
        var x = this.engine.inputManager.mousePos.x;
        var y = this.engine.inputManager.mousePos.y;
        if(this.engine.inputManager.activeInputs["MouseClick0"]&&(900<x)&&(x<1050)&&(400<y)&&(y<550)){
            console.log("click");
            this.inUse = !this.inUse;
        }
    }

    draw() {
        if (this.inUse == false) {
            this.engine.ctx.drawImage(
                this.image2,
                this.position.x, this.position.y,
                this.scale.x, this.scale.y
            )
        } else {
            this.engine.ctx.drawImage(
                this.image1,
                this.position.x, this.position.y,
                this.scale.x, this.scale.y
            )
        }
    }
}