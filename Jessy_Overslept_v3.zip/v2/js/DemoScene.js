class DemoScene extends Scene {
    constructor(engine) {
        super(engine);

        this.name = "Demo Scene";
        this.cursorState = "hand_bare";

        // this.video = document.createElement("video"); // create a video element
        // this.video.src = "./mp4/entering.mp4";
        // // this.video.onload();
        // this.video.autoplay = false;
        // this.video.loop = false;
        // this.video.oncanplay = true;
        // this.videoContainer = {  // we will add properties as needed
        //     video : this.video,
        //     ready : false,   
        // };

        this.setup();
    }

    setup() {
        // Boilerplate testing
        // Adding simple assets to the db
        for (var i = 0; i < 10; i++) {
            this.assetDB.add("asset" + i, i);
        }

        // Adding script assets to the db
        this.assetDB.add("script0", () =>{  document.body.innerHTML += "<br>script0 has been called"; });

        // let player = new PlayerObject(this.engine);
        //let player2 = new PlayerObject(this.engine);
        //let player3 = new PlayerObject(this.engine);
        let knifetool = new Knife(this.engine);
        let hemostattool = new Hemostat(this.engine);
        let bloodBar = new BloodBar(this.engine);
        let energyBar = new EnergyBar(this.engine);
        let idcard = new IDcard(this.engine);

        
        let brain1 = new Brain1(this.engine,"./img/brain/1-1.png","./img/brain/1-2.png")
        let brain2 = new Brain1(this.engine,"./img/brain/2-1.png","./img/brain/2-2.png")
        let brain3 = new Brain1(this.engine,"./img/brain/3-1.png","./img/brain/3-2.png")
        let brain4 = new Brain1(this.engine,"./img/brain/4-1.png","./img/brain/4-2.png")
        let brain5 = new Brain1(this.engine,"./img/brain/5-1.png","./img/brain/5-2.png")
        let brain6 = new Brain1(this.engine,"./img/brain/6-1.png","./img/brain/6-2.png")
        let brain7 = new Brain1(this.engine,"./img/brain/7-1.png","./img/brain/7-2.png")
        let brain8 = new Brain1(this.engine,"./img/brain/8-1.png","./img/brain/8-2.png")
        let brain9 = new Brain1(this.engine,"./img/brain/9-1.png","./img/brain/9-2.png")
        let brain10 = new Brain1(this.engine,"./img/brain/10-1.png","./img/brain/10-2.png")
        let brain11 = new Brain1(this.engine,"./img/brain/11-1.png","./img/brain/11-2.png")
        let brain12 = new Brain1(this.engine,"./img/brain/12-1.png","./img/brain/12-2.png")
        let brain13 = new Brain1(this.engine,"./img/brain/13-1.png","./img/brain/13-2.png")
        let brain = new Brain1(this.engine,"./img/brain/whole brain_empty.png","./img/brain/whole brain_red.png")

        // let block1 = new BlockObject(this.engine);
        // let block2 = new BlockObject(this.engine);
        // let block3 = new BlockObject(this.engine);
        // let block4 = new BlockObject(this.engine);

        // block1.transform.position = { x: 200, y: 450 };
        // block2.transform.position = { x: 400, y: 400 };
        // block3.transform.position = { x: 450, y: 400 };
        // block4.transform.position = { x: 500, y: 450 };
        brain13.status = false;
        brain13.name = "badbrain";


        //player2.name = "P2";
        //player3.name = "P3";

        //player2.transform.position = {x: 200, y: 380};
        //player2.invertX = -1;
        //player2.collider = new CircleCollider(player2, 20);

        //player2.freezeAxis = {x:true, y: true};

        //player3.translate( {x: 250, y: 0} );
        //player3.invertX = -1;
        //player3.collider = new CircleCollider(player3, 20);

        this.instantiate(knifetool);
        this.instantiate(hemostattool);
        this.instantiate(bloodBar);
        this.instantiate(energyBar);
        this.instantiate(idcard);

        this.instantiate(brain1);
        this.instantiate(brain2);
        this.instantiate(brain3);
        this.instantiate(brain4);
        this.instantiate(brain5);
        this.instantiate(brain6);
        this.instantiate(brain7);
        this.instantiate(brain8);
        this.instantiate(brain9);
        this.instantiate(brain10);
        this.instantiate(brain11);
        this.instantiate(brain12);
        this.instantiate(brain13);
        this.instantiate(brain);

        //this.instantiate(player2);
        //this.instantiate(player3);

        // this.instantiate(block1);
        // this.instantiate(block2);
        // this.instantiate(block3);
        // this.instantiate(block4);
        var i;
        for(i=0; i<13;i++){

        }
    }

    update(time) {
        // Using default update order
        super.update(time);
        // if(knifetool.checkuse() == true){
        //     this.cursorState = "hand_knife";
        // }
        // if (this.win) {
        //     this.videoContainer.ready = true;
        //     this.videoContainer.scale = Math.min(
        //         this.engine.canvas.width / this.videoContainer.video.videoWidth, 
        //         this.engine.canvas.height / this.videoContainer.video.videoHeight);
        // }
        
        
    }


    render() {
        // Using default rendering order
        super.render();
        // if (this.videoContainer.ready) {
        //     // this.video.oncanplay = this.readyToPlayVideo();
        //     this.updateCanvas();
            
        // }
    }

    // updateCanvas(){
    //     this.engine.ctx.clearRect(0,0,this.engine.canvas.width,this.engine.canvas.height); // Though not always needed 
    //                                                      // you may get bad pixels from 
    //                                                      // previous videos so clear to be
    //                                                      // safe
    //     // only draw if loaded and ready
    //     if(this.videoContainer !== undefined && this.videoContainer.ready){ 
    //         // find the top left of the video on the canvas
    //         var scale = this.videoContainer.scale;
    //         var vidH = this.videoContainer.video.videoHeight;
    //         var vidW = this.videoContainer.video.videoWidth;
    //         var top = this.engine.canvas.height / 2 - (vidH /2 ) * scale;
    //         var left = this.engine.canvas.width / 2 - (vidW /2 ) * scale;
    //         // now just draw the video the correct size
    //         this.engine.ctx.drawImage(this.videoContainer.video, left, top, vidW * scale, vidH * scale);
    //         // if(this.videoContainer.video.paused){ // if not playing show the paused screen 
    //         //     drawPayIcon();
    //         // }
    //     }
    //     // all done for display 
    //     // request the next frame in 1/60th of a second
    //     // requestAnimationFrame(this.updateCanvas());
    // }
    
    // readyToPlayVideo(){ // this is a referance to the video
    //     // the video may not match the canvas size so find a scale to fit
    //     this.videoContainer.scale = Math.min(
    //                          this.engine.canvas.width / this.videoContainer.video.videoWidth, 
    //                          this.engine.canvas.height / this.videoContainer.video.videoHeight); 
    //     this.videoContainer.ready = true;
    //     // the video can be played so hand it off to the display function
    //     requestAnimationFrame(this.updateCanvas());
    // }

}
