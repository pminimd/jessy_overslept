class BodyObject extends GameObject{
    constructor(engine) {
        super(engine);

        this.engine = engine;
        this.position = {x:100,y:100};
        // this.scale = {x:100,y:100};
        this.imgpath1 = "";//"./img/brain.png";
        this.imgpath2 = "";//imagepath2;//".";
        
        // this.image1 = document.createElement("img");
        // this.image2 = document.createElement("img");
        // this.image1.src = this.imgpath1;
        // this.image2.src = this.imgpath2;
        // this.image1.onload = () => {
        //     console.log("brain.png ok");
        // };
        // this.image2.onload = () => {
        //     console.log("_.png ok");
        // };
        // this.image = null;
        this.status = true;//status: good or bad

        console.log("=====");
        this.name = "Brain";
    }

    update(time) {
        //brain的状态是否需要改变
        // if (this.status == "good"){
        //     this.image = this.image1;
        //     console.log("hhhh")
        // }else{
        //     this.image = this.image2;
        // }
    }

    draw() {
        // draw()
        // console.log("hi, draw body part");
        // this.engine.ctx.drawImage(
        //     this.image,
        //     this.position.x,this.position.y);
    }
}