class SecondScene extends Scene {
    constructor(engine) {
        super(engine);

        this.engine = engine;
        this.name = "Second Scene";

        this.imgpath1 = "./img/jessy.png";//换成一个新的字体Png
        this.image1 = document.createElement("img");
        this.image1.src = this.imgpath1;
        this.image1.onload = () => {
            console.log("jessy.png ok");
        };

        this.imgpath2 = "./img/hospital.png";//换成一个新的字体Png
        this.image2 = document.createElement("img");
        this.image2.src = this.imgpath2;
        this.image2.onload = () => {
            console.log("hospital.png ok");
        };

        this.setup();
    }

    setup() {
        // Boilerplate testing
        // Adding simple assets to the db
        for (var i = 0; i < 10; i++) {
            this.assetDB.add("asset" + i, i);
        }

        // Adding script assets to the db
        this.assetDB.add("script0", () =>{  document.body.innerHTML += "<br>script0 has been called"; });

        let player = new PlayerObject(this.engine);
        player.position = {x: 0,y: this.engine.ctx.height};
        console.log(player.name)

        let bloodBar = new BloodBar(this.engine);
        let energyBar = new EnergyBar(this.engine);
        let idcard = new IDcard(this.engine);
        //let player2 = new PlayerObject(this.engine);
        //let player3 = new PlayerObject(this.engine);
        // let bloodBar = new BloodBar(this.engine);
        // let energyBar = new EnergyBar(this.engine);

        // let block1 = new BlockObject(this.engine);
        // let block4 = new BlockObject(this.engine);
        // let block5 = new BlockObject(this.engine);

        // bloodBar.transform.position = { x: 400, y: 20 };

        // block1.transform.position = { x: 100, y: 450 };
        // block4.transform.position = { x: 500, y: 450 };
        // block5.transform.position = { x: 600, y: 450 };


        //player2.name = "P2";
        //player3.name = "P3";

        //player2.transform.position = {x: 200, y: 380};
        //player2.invertX = -1;
        //player2.collider = new CircleCollider(player2, 20);

        //player2.freezeAxis = {x:true, y: true};

        //player3.translate( {x: 250, y: 0} );
        //player3.invertX = -1;
        //player3.collider = new CircleCollider(player3, 20);

        this.instantiate(player);

        this.instantiate(bloodBar);
        this.instantiate(energyBar);
        this.instantiate(idcard);
        //this.instantiate(player2);
        //this.instantiate(player3);
        // this.instantiate(bloodBar);
        // this.instantiate(energyBar);

        // this.instantiate(block1);
        // this.instantiate(block4);
        // this.instantiate(block5);
    }

    update(time) {
        // Using default update order
        super.update(time);
        if (this.die) {
            //触发惊醒的动画，杰西没有跑进医院，这里跳转一个场景代替
            // alert("die");
            this.engine.setScene(scenes[2]);
        }
    }


    render() {
        // Using default rendering order
        this.engine.ctx.drawImage(
            this.image2,
            800,-200,
        );
        super.render();
        this.engine.ctx.drawImage(
            this.image1,
            0,0
        );
        
        
        // console.log(this.engine.inputManager.mousePos.x);
    }


}
