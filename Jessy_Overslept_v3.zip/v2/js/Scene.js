class Scene {
    // Base class for scenes

    constructor(engine) {
        this.assetDB = new AssetDB();
        this.engine = engine;
        this.gameObjects = [];
        this.name = "New Scene";

        //bare hand
        this.hand = document.createElement("img");
        this.hand.src = "./img/hand/hand_bare.png"
        this.hand.onload = () => {
            console.log("hand_bare.png ok");
        };

        //knife in hand
        this.knifeinhand = document.createElement("img");
        this.knifeinhand.src = "./img/hand/hand_knife.png"
        this.knifeinhand.onload = () => {
            console.log("hand_knife.png ok");
        };

        //hemostat in hand
        this.hemostatinhand = document.createElement("img");
        this.hemostatinhand.src = "./img/hand/hand_hemostat.png"
        this.hemostatinhand.onload = () => {
            console.log("hand_hemostat.png ok");
        };

        this.cursorState = "none";
        this.die = false;//to trigger the random red
        this.win = false;//to check if success
        this.enter = false;//
        
        this.wakeupdie = false;

        this.initialise();
    }

    initialise() {
        this.gameObjects.remove = function() {
            // Taken from StackOverflow
            // https://stackoverflow.com/questions/3954438/how-to-remove-item-from-array-by-value
            var what, a = arguments, L = a.length, ax;
            while (L && this.length) {
                what = a[--L];
                while ((ax = this.indexOf(what)) !== -1) {
                    this.splice(ax, 1);
                }
            }
            return this;
        }
    }

    findAsset(name) {
        return this.assetDB.find(name);
    }

    getAssetCount() {
        return this.assetDB.count;
    }

    update(time) {
        // Stub, to be implemented

        for (let gameObject of this.gameObjects) {
            if (gameObject.active) {
                gameObject.update(time);
            }

            //TODO: 如果看见喷血，数值就开始变化
            if (this.die){
                if (gameObject.name == "Brain"){
                    gameObject.status = false;
                    //TODO:触发随机动画
                    //TODO:触发“惨叫”声音
                }
            }

            if (this.win){
                //TODO:add win 动画
            }else{
                //能量条开始降低
                if (gameObject.name == "EnergyBar"){
                    gameObject.nownum = gameObject.nownum - 0.05;
                    if (gameObject.nownum < 0.1){
                        // alert("FAILED !!!");
                        this.die = true;
                        console.log("die");
                    }
                }

                //血条降低
                if (gameObject.name == "BloodBar"){
                    gameObject.nownum = gameObject.nownum - 0.1;
                    if (gameObject.nownum < 0.1){
                        // alert("FAILED !!!"); 
                    }
                }

                // if ((gameObject.name == "Knife" )||(gameObject.name == "Hemostat") ){
                //     // console.log(gameObject.name);
                //     var hand = {Knife: false, Hemostat: false}
                //     if (gameObject.name == "Knife"){
                //         hand.Knife = gameObject.inUse;
                //     }else{
                //         hand.Hemostat = gameObject.inUse;
                //     }
                //     if (hand.Knife == true){
                //         // console.log("fuck:",gameObject.hand);
                //         this.cursorState = "hand_knife";
                //         // break;
                //     }else if (hand.Hemostat == true) {
                //         this.cursorState = "hand_hemostat";
                //     }else{
                //         this.cursorState = "hand_bare";
                //     }
                // }

                // var hand = {Knife: false, Hemostat: false}
                // if (gameObject.name == "Knife") {
                //     hand.Knife = gameObject.inUse;
                // }
                // if (gameObject.name == "Hemostat") {
                //     // console.log("hemo");
                //     hand.Hemostat = gameObject.inUse;
                // }
                // if (hand.Knife == true) {
                //     this.cursorState == "hand_knife";
                // }
                // if (hand.Hemostat == true) {
                //     // console.log("hello");
                //     this.cursorState == "hand_hemostat";
                // }
                // if ((hand.Knife == false)&&(hand.Hemostat == false)) {
                //     this.cursorState == "hand_bare";
                // }

                if ((gameObject.name == "Knife" )||(gameObject.name == "Hemostat") ){
                    // console.log(gameObject.name);
                    if (gameObject.inUse == true){
                        // console.log("fuck:",gameObject.hand);
                        this.cursorState = gameObject.hand;
                        // break;
                    }else{
                        this.cursorState = "hand_bare";
                    }
                }

                if (gameObject.name == "badbrain") {
                    if (gameObject.status){
                        console.log("I am good");
                        this.win = true;//触发通关
                        break;
                    }
                }

                if (gameObject.name == "PlayerObject"){
                    console.log(gameObject.transform.position.x);
                    if (gameObject.transform.position.x > 1200) {
                        this.enter = true;
                        this.engine.setScene(scenes[1]);
                    }
                }
                

            }//没有通关时候的循环
        }//gameObject的循环
    }

    render() {
        // Stub, to be implemented
        for (let gameObject of this.gameObjects) {
            if (gameObject.active) {
                gameObject.draw();
            }
        }
        if (this.win) {
            //触发一个15秒动画
        }
        if (this.enter) {
            this.engine.ctx.fillStyle = "black"
            this.engine.ctx.fillRect(
                            0,0,
                            this.engine.canvas.width,this.engine.canvas.height
                        )
        }
    }

    drawCursor() {

        let mx = this.engine.inputManager.mousePos.x;
        let my = this.engine.inputManager.mousePos.y;

        //mx += this.engine.inputManager.mouseVelocity.x;
        //my += this.engine.inputManager.mouseVelocity.y;
        switch(this.cursorState) {
            case "none":
                // code;
                this.engine.ctx.beginPath();
                this.engine.ctx.strokeStyle = "black";
                this.engine.ctx.lineWidth = "4";
                this.engine.ctx.rect(mx -2, my -2, 4, 4);
                this.engine.ctx.stroke();
                break;
            case "hand_bare":
                this.engine.ctx.drawImage(
                    this.hand,
                    mx-100,my-100            
                )
                break;
            case "hand_knife":
                this.engine.ctx.drawImage(
                    this.knifeinhand,
                    mx-100,my-100
                )
                break;
            case "hand_hemostat":
                this.engine.ctx.drawImage(
                    this.hemostatinhand,
                    mx-100,my-100
                )
                break;
        }
    }

    instantiate(gameObject) {
        this.gameObjects.push(gameObject);
    }

    destroy(gameObject, delay) {
        // Removes given GameObject from the world

        if (delay == undefined) delay = 0;
        if (delay < 0) delay = 0;

        setTimeout(() => {
            this.gameObjects.remove(gameObject);
        }, delay);
    }

}
