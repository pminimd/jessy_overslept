class BloodBar extends InfoBarObject{
    constructor(engine) {
        super(engine);
        this.position = {x:79,y:108};
        this.maxnum = 105;
        this.scale = {x:this.maxnum,y:8};
        this.nownum = 100
        this.color = "black";//"#E71E0A";
        this.name = "BloodBar";
    }
}