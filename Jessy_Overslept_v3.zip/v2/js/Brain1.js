class Brain1 extends BodyObject{
    constructor(engine,imgpath1,imgpath2) {
        super(engine);

        this.engine = engine;
        this.position = {x:100,y:100};
        this.scale = {x:100,y:100};
        this.imgpath1 = imgpath1;//"./img/brain/1-1.png";
        this.imgpath2 = imgpath2;//"./img/brain/1-2.png";
        
        this.image1 = document.createElement("img");
        this.image2 = document.createElement("img");
        this.image1.src = this.imgpath1;
        this.image2.src = this.imgpath2;
        this.image1.onload = () => {
            console.log("brain1_good.png ok");
        };
        this.image2.onload = () => {
            console.log("brain1_bad.png ok");
        };
        this.status = true;//status: true for good and false for bad

        this.name = "Brain";
    }

    update(time) {
        //brain的状态是否需要改变
        var x = this.engine.inputManager.mousePos.x;
        var y = this.engine.inputManager.mousePos.y;
        if(this.engine.inputManager.activeInputs["MouseClick0"]&&this.name == "badbrain"&&this.inarea(x,y)){
            console.log("click, x:",x,"y:",y);
            this.status = !this.status;
        }
    }

    inarea(a,b) {
        console.log("used");
        console.log(9*a+13*b-8528);
        console.log(3*a-4*b-601); 
        console.log(4*a+11*b-6197);
        console.log(1*a-1*b-334);

        if(((9*a+13*b-8528)>0)&&((3*a-4*b-601)>0)&&((4*a+11*b-6197)<0)&&((a-b-334)<0)){
            return true;
        }else{
            return false;
        }
    }

    draw() {
        // draw()
        if (this.status) {
            this.engine.ctx.drawImage(
                this.image1,
                this.position.x, this.position.y,
            )
        } else {
            this.engine.ctx.drawImage(
                this.image2,
                this.position.x, this.position.y,
            )
        }
    }
}